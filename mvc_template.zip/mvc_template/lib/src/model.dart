export 'package:mvc_application/model.dart';

export 'package:mvc_template/src/home/model/model.dart';
