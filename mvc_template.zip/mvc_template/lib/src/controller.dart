export 'package:mvc_application/controller.dart'
    show App, AppConMVC, AppController, AppDrawer, ControllerMVC, runApp
    hide HandleError;

export 'package:mvc_application/settings.dart' show AppSettings, Prefs;

export 'package:mvc_template/src/app/controller/controller.dart';

export 'package:mvc_template/src/home/controller/controller.dart';
