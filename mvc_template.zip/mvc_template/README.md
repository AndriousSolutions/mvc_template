# mvctemplate

Flutter Project Template using the MVC architecture.
